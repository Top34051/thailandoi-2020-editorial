#!/bin/bash

problem=castle

g++ -std=gnu++14 -O2 -pipe -o $problem main.cpp $problem.cpp

