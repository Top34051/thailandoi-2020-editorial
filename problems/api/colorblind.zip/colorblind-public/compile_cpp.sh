#!/bin/bash

g++ -std=c++14 -O2 -pipe grader.cpp colorblind.cpp -o colorblind
