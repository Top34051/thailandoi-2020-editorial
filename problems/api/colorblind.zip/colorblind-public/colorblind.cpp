#include "colorblind.h"

std::string investivate_colors(int N) {
	// your code here
	
	int ret;
	
	ret = use_device(0, 1);
	ret = use_device(3, 2);

	return "moozmooz";
}