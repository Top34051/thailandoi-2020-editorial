#include <string>

std::string investivate_colors(int N);
int use_device(int a, int b);
